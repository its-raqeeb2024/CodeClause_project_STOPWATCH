# STOPWATCH

STOPWATCH (Made using HTML5 CSS3 and JavaScript)

You can see the website live at: https://5codeman.github.io/STOPWATCH/

Project demo video Link: https://www.youtube.com/watch?v=QeLBZmgMxLc

ABOUT THIS PROJECT-:

  1. In this project i have created a simple stopwatch using HTML CSS and JavaScript.
  2. In the Stopwatch there are three buttons start, pause, and reset for operating the stopwatch.
  3. The main logic use in this stopwatch project is the set interval function.
